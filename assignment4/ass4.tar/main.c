#include<stdio.h>
#include "maxHeap.h"
int main(){
    maxHeap tnode;
    int size = 5;
    initMaxHeap(&tnode,size);
    insert(&tnode,12);
    insert(&tnode,35);
    insert(&tnode,66);
    insert(&tnode,71);
    insert(&tnode,54);
    insert(&tnode,92);
    insert(&tnode,13);
    insert(&tnode,18);
    insert(&tnode,20);
    insert(&tnode,25);
    insert(&tnode,60);
    insert(&tnode,13);
    // heapSort(&tnode);
    // display(tnode);
    display(tnode);
    // printf("\nPopNode = %d",PopNode(&tnode));
    // display(tnode);
}