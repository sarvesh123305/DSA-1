#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include "maxHeap.h"

#define PARENT (i-1)/2
#define SIZE tnode -> size
#define ARR tnode -> arr
void initMaxHeap(maxHeap* tnode,int size){
    tnode -> size = size;
    tnode -> arr = NULL;
    tnode -> rear = -1;
    tnode -> arr = (int*)malloc(sizeof(int)*size);
}

void swap(int *a,int *b){
    int temp = *a;
    *a = *b;
    *b = temp;
}
void heapify(maxHeap* tnode){
    int i = SIZE-1 ;
    while(i > 0){
        if(ARR[i] > ARR[(i-1)/2]){
            swap(&ARR[i],&ARR[(i-1)/2]);
        }
        i = (i-1)/2;
    }
}
void insert(maxHeap* tnode,int data){
    tnode -> rear += 1;
    if(tnode -> rear == SIZE){
        tnode -> arr = (int *) realloc(tnode -> arr,sizeof(int)*(tnode -> size*2));
        SIZE = SIZE * 2;
    }
    tnode -> arr[tnode -> rear] = data;
    int i = tnode -> rear ;

    while( i > 0){
        if(tnode -> arr[i] > tnode -> arr[PARENT])
        {
            swap(&tnode -> arr[i],&tnode -> arr[PARENT]);
            i = PARENT;
        }
        else
            return;
    }
}

void heapSort(maxHeap* tnode){
    for(int i = SIZE-1 ; i >= (SIZE+1)/2 ; i--){
        heapify(tnode);
    }
}

int PopNode(maxHeap* tnode){
    if(tnode -> size == 0)
        return INT_MIN;
    
    int tempAns = tnode -> arr[0];
    tnode -> arr[0] = tnode -> arr[tnode -> size-1];
    SIZE--;
    int i = 0;
    while(i < (SIZE+1)/2){
        // printf("Iterations \n");
        int leftIndex = i*2+1;
        int rightIndex = i*2 + 2;
        int temp = i;
        if(leftIndex < SIZE && tnode -> arr[i] < tnode -> arr[leftIndex]){
            i = leftIndex;
        }
        if(rightIndex < SIZE && tnode -> arr[i] < tnode -> arr[rightIndex]){
            i = rightIndex;
        }
        if(i != temp){
        swap(&tnode -> arr[temp] , &tnode -> arr[i]);
        }
        else{
            i++;
        }
            // return tempAns;
    } 
    return tempAns;
}
void display(maxHeap tnode){
    printf("\n ");
    for(int i = 0 ; i <= tnode.rear ;i++){
        printf("%d ",tnode.arr[i]);
    }
    printf("\n");
}
