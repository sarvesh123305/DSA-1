

typedef struct maxHeap{
    int size ;
    int rear;
    int *arr;
}maxHeap;

void initMaxHeap(maxHeap*,int);
void insert(maxHeap*,int);
int PopNode(maxHeap*);
void display(maxHeap);
void heapSort(maxHeap*);