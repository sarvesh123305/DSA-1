gcc main.c binaryTree.c  ../bst/BST.c 
./a.out  1000 100 1000 file1.txt > file2.txt
#./a.out 1000 100 1000 file1.txt
