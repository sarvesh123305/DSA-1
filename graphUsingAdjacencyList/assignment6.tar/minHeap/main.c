#include<stdio.h>
#include "minHeap.h"
int main(){
    minHeap tnode;
    initminHeap(&tnode,5);
    // Data data1;
    // data1.start = 1;
    // data1.end = 2;
    // data1.weight = 3;

    // Data data2;
    // data2.start = 1;
    // data2.end = 2;
    // data2.weight = 4;
    
    // Data data3;
    // data3.start = 1;
    // data3.end = 2;
    // data3.weight = 1;


    // insert(&tnode,data1);
    // insert(&tnode,data2);
    // insert(&tnode,data3);

    // while(tnode.rear != -1){
    //     int temp = popNode(&tnode);
    //     printf("%d \t",temp);
    // }
    // insert(&tnode,7);
    // insert(&tnode,71);
    // insert(&tnode,54);
    // insert(&tnode,92);
    // insert(&tnode,13);
    // insert(&tnode,18);
    // insert(&tnode,20);
    // insert(&tnode,25);
    // insert(&tnode,60);

    // while(tnode.rear != -1){
    //     printf("%d ",popNode(&tnode));
    // }
    // popNode(&tnode);
    // popNode(&tnode);


    // insert(&tnode,100);
    // insert(&tnode,20);
    // insert(&tnode,50);


    // heapSortAscending(&tnode);
    // display(tnode);

   
}