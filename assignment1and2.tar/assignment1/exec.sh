gcc main.c bst/BST.c BinaryTree/binarytree.c
