gcc main.c ../bst/BST.c  binaryTree.c ../../genericQueue/queue.c

./a.out  1000 100 1000 file1.txt > file2.txt
#./a.out 1000 100 1000 file1.txt
