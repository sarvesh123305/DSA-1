gcc graph.c ../genericQueue/queue.c main.c; ./a.out
