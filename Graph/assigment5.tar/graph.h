#include<stdio.h>

typedef struct graph{
    int **A;
    int size;
}graph;

void initGraph(graph*);
void BFS(graph g,int s);
void degreeOfEachVertex(graph g);
int isGraphConnected(graph g);
int isAdjcantToAnother(graph g,int v,int e);
void display(graph);