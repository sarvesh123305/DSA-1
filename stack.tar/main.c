#include<stdio.h>
#include "stack.h"

int main(){

    Stack s;
    initStack(&s,10);
}