#include "stack.h"
#include<stdlib.h>
#include<stdio.h>


void initStack(Stack *s,int size){
    s -> top = -1;
    s -> arr = (int*)malloc(sizeof(int) * size);
    s -> size = size;
    return;
}
int isFull(Stack s){
    return (s.top == s.top - 1);
}
void pushToStack(Stack* s,int data){
    if(isFull(*s)){
        return ;  
    }
    else{
        s -> top++;
        s -> arr[s -> top] = data;
    }
}
// void displayStack(Stack s){
//     snode* temp = s;
//     printf("\n");
//     while(temp){
//         printf("%d ",temp -> data -> data);
//         temp = temp -> next;
//     }
//     printf("\n");
//     return ;
// }
// snode* pop(Stack* s){
//     snode* deleteNode;
//         // printf("%d ",s -> top -> data -> data);

//     if(isEmpty(*s)){
//         // printf("dar");
//         return NULL;
//     }
//     else{
//         deleteNode = *s;
//         (*s)  = (*s) -> next;
//     }
//     // free(deleteNode);
//     return deleteNode;
// }
int isEmpty(Stack s){
    return ( s.top == -1);
}

int top(Stack s){
    if(isEmpty(s))
        return -1;
    return s.arr[s.top] ;
}