

typedef struct stack{
    int top;
    int size;
    int *arr;
}stack;

typedef stack Stack ;

void initStack(Stack*,int);
void pushToStack(Stack*,int );
int isEmpty(Stack s);
// snode* pop(Stack*);
// int isEmpty(Stack);
// void displayStack(Stack);
// snode* top(Stack s);
